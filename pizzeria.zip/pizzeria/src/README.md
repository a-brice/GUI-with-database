
Décompressez le fichier .zip et lancer le PizzeriaApp/ProjetWPFV2.sln avec Visual Studio pour pouvoir visualiser le programme
