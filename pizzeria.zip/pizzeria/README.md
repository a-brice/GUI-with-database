
<h1>Logiciel de gestion d'une pizzeria</h1>

Par l'intermédiaire de fichier aux format CSV, nous avions à réaliser un système de gestion de pizzeria en binôme.

Cela impliquait la gestion du personnel, des produit et des commandes effectuées mais aussi des clients sans oublier l'enregistrements, la modification et la destruction de toutes ces données dans les fichiers attitrés.

Pour créer cette application, nous avions dû créer un diagramme UML pour représenter la solution du problème : 

<p align="center">
<img width="607" alt="UML_Solution" src="https://user-images.githubusercontent.com/78383419/109863802-5cc53780-7c62-11eb-8976-0f3c80659d8a.png">
</p>
